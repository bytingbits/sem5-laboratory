// client.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <time.h>

#define PORT 8080
#define BUFFER_SIZE 4096

void parse_and_display_marks(const char *html_response) {
    const char *start_ptr = html_response;
    const char *semester_marker = "<tr><td>Semester";
    const char *subject_marker = "<td>";
    const char *end_td_marker = "</td>";

    while ((start_ptr = strstr(start_ptr, semester_marker)) != NULL) {
        start_ptr += strlen(semester_marker);
        const char *end_ptr = strstr(start_ptr, end_td_marker);
        if (end_ptr) {
            printf("Semester: %.*s\n", (int)(end_ptr - start_ptr), start_ptr);
            start_ptr = end_ptr + strlen(end_td_marker);

            start_ptr = strstr(start_ptr, subject_marker);
            if (start_ptr) {
                start_ptr += strlen(subject_marker);
                end_ptr = strstr(start_ptr, end_td_marker);
                if (end_ptr) {
                    printf("Subject: %.*s\n", (int)(end_ptr - start_ptr), start_ptr);
                    start_ptr = end_ptr + strlen(end_td_marker);

                    start_ptr = strstr(start_ptr, subject_marker);
                    if (start_ptr) {
                        start_ptr += strlen(subject_marker);
                        end_ptr = strstr(start_ptr, end_td_marker);
                        if (end_ptr) {
                            printf("Marks: %.*s\n", (int)(end_ptr - start_ptr), start_ptr);
                            start_ptr = end_ptr + strlen(end_td_marker);
                            printf("\n");
                        }
                    }
                }
            }
        }
    }
}

int main() {
    int sock = 0;
    struct sockaddr_in serv_addr;
    char request[] = "GET / HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: keep-alive\r\n\r\n";
    char buffer[BUFFER_SIZE] = {0};
    clock_t start_time, end_time;
    double response_time;

    // Create socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation error");
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    // Convert IPv4 and IPv6 addresses from text to binary form
    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        perror("Invalid address / Address not supported");
        return -1;
    }

    // Connect to the server
    start_time = clock();
    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Connection failed");
        return -1;
    }
    end_time = clock();
    response_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    printf("Connection time: %f seconds\n", response_time);

    // Send HTTP GET request
    write(sock, request, strlen(request));

    // Read response from the server
    start_time = clock();
    int valread = read(sock, buffer, BUFFER_SIZE - 1);
    end_time = clock();
    response_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    printf("Response time: %f seconds\n", response_time);

    // Null-terminate the response
    buffer[valread] = '\0';

    // Print the raw response
    // printf("%s\n", buffer);

    // Parse and display subjects and marks
    parse_and_display_marks(buffer);

    // Close socket
    close(sock);

    return 0;
}

