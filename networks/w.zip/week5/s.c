// server.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <time.h>

#define PORT 8080
#define BUFFER_SIZE 4096

void send_response(int client_socket) {
    FILE *file = fopen("marks.html", "r");
    if (file == NULL) {
        perror("Could not open HTML file");
        return;
    }

    char response[BUFFER_SIZE];
    int bytes_read = fread(response, 1, sizeof(response) - 1, file);
    if (bytes_read < 0) {
        perror("Error reading HTML file");
        fclose(file);
        return;
    }
    response[bytes_read] = '\0'; // Null-terminate the string

    char header[1024];
    snprintf(header, sizeof(header),
             "HTTP/1.1 200 OK\r\n"
             "Content-Type: text/html\r\n"
             "Connection: keep-alive\r\n"
             "Content-Length: %d\r\n"
             "\r\n", bytes_read);

    // Send header
    write(client_socket, header, strlen(header));

    // Send response
    write(client_socket, response, bytes_read);

    fclose(file);
}

int main() {
    int server_fd, client_socket;
    struct sockaddr_in address;
    int addr_len = sizeof(address);
    clock_t start_time, end_time;
    double response_time;

    // Create socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    // Bind socket
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    while (1) {
        printf("Waiting for connections...\n");

        // Accept connection
        if ((client_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addr_len)) < 0) {
            perror("Accept failed");
            exit(EXIT_FAILURE);
        }

        printf("Connection accepted\n");

        start_time = clock();
        send_response(client_socket);
        end_time = clock();

        response_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
        printf("Response time: %f seconds\n", response_time);

        close(client_socket);
    }

    return 0;
}

