#include <stdio.h>                                                                                                                                    
#include <stdlib.h>                                                                                                                                   
#include <string.h>                                                                                                                                   
#include <unistd.h>                                                                                                                                   
#include <arpa/inet.h>                                                                                                                                
#include <time.h>                                                                                                                                     
                                                                                                                                                      
#define SERVER_IP "127.0.0.1"                                                                                                                         
#define PORT 5556                                                                                                                                     
#define BUFFER_SIZE 4096                                                                                                                              
                                                                                                                                                      
int create_socket() {                                                                                                                                 
        int sockfd;                                                                                                                                   
        struct sockaddr_in server_addr;                                                                                                               
                                                                                                                                                      
        sockfd = socket(AF_INET, SOCK_STREAM, 0);                                                                                                     
        if (sockfd < 0) {                                                                                                                             
                perror("socket");                                                                                                                     
                exit(EXIT_FAILURE);                                                                                                                   
        }                                                                                                                                             
                                                                                                                                                      
        server_addr.sin_family = AF_INET;                                                                                                             
        server_addr.sin_port = htons(PORT);                                                                                                           
        server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);                                                                                           
                                                                                                                                                      
        if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {                                                              
                perror("connect");                                                                                                                    
                close(sockfd);                                                                                                                        
                exit(EXIT_FAILURE);                                                                                                                   
        }                                                                                                                                             
                                                                                                                                                      
        return sockfd;                                                                                                                                
}                                                                                                                                                     
                                                                                                                                                      
void extract_marks(const char *html) {                                                                                                                
        const char *start_marker = "<td>";                                                                                                            
        const char *end_marker = "</td>";                                                                                                             
        const char *next_row_marker = "<tr>";                                                                                                         
                                                                                                                                                      
        char *start, *end;                                                                                                                            
        int len;                                                                                                                                      
        int first_td = 1;                                                                                                                             
                                                                                                                                                      
        start = strstr(html, next_row_marker);                                                                                                        
        while (start) {                                                                                                                               
                start = strstr(start, start_marker);                                                                                                  
                while (start && (end = strstr(start, end_marker))) {                                                                                  
                        len = end - start - strlen(start_marker);                                                                                     
                        if (len > 0) {                                                                                                                
                                char mark[len + 1];                                                                                                   
                                strncpy(mark, start + strlen(start_marker), len);                                                                     
                                mark[len] = '\0';                                                                                                     
                                                                                                                                                      
                                if (!first_td) {                                                                                                      
                                        printf("%s\n", mark);                                                                                         
                                } else {                                                                                                              
                                        first_td = 0;                                                                                                 
                                }                                                                                                                     
                        }                                                                                                                             
                        start = strstr(end + strlen(end_marker), start_marker);                                                                       
                }                                                                                                                                     
                start = strstr(end + strlen(end_marker), next_row_marker);                                                                            
        }                                                                                                                                             
}                                                                                                                                                     
                                                                                                                                                      
int main() {                                                                                                                                          
        int sockfd;                                                                                                                                   
        char request[] =                                                                                                                              
                "GET / HTTP/1.1\r\n"                                                                                                                  
                "Host: localhost\r\n"                                                                                                                 
                "Connection: close\r\n\r\n";                                                                                                          
        char response[BUFFER_SIZE];                                                                                                                   
        int bytes;                                                                                                                                    
                                                                                                                                                      
        sockfd = create_socket();                                                                                                                     
                                                                                                                                                      
        clock_t start_time = clock();                                                                                                                 
                                                                                                                                                      
        if (send(sockfd, request, strlen(request), 0) < 0) {                                                                                          
                perror("send");                                                                                                                       
                close(sockfd);                                                                                                                        
                exit(EXIT_FAILURE);                                                                                                                   
        }                                                                                                                                             
                                                                                                                                                      
        char html_response[BUFFER_SIZE] = {0};                                                                                                        
        int total_bytes = 0;                                                                                                                          
        while ((bytes = recv(sockfd, response, sizeof(response) - 1, 0)) > 0) {                                                                       
                response[bytes] = '\0';                                                                                                               
                strcat(html_response, response);                                                                                                      
                total_bytes += bytes;                                                                                                                 
        }                                                                                                                                             
                                                                                                                                                      
        if (bytes < 0) {                                                                                                                              
                perror("recv");                                                                                                                       
        }                                                                                                                                             
                                                                                                                                                      
        clock_t end_time = clock();                                                                                                                   
        double response_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;                                                                      
        printf("Total Response Time: %.6f seconds\n", response_time);                                                                                 
                                                                                                                                                      
        extract_marks(html_response);                                                                                                                 
                                                                                                                                                      
        close(sockfd);                                                                                                                                
                                                                                                                                                      
        return 0;                                                                                                                                     
}
