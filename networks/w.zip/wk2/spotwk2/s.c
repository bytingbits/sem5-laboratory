#include <stdio.h>                                                                                                                                     
#include <stdlib.h>                                                                                                                                    
#include <string.h>                                                                                                                                    
#include<math.h>                                                                                                                                       
#include <unistd.h>                                                                                                                                    
#include <arpa/inet.h>                                                                                                                                 
                                                                                                                                                       
#define PORT 6533                                                                                                                                      
#define BUFFER_SIZE 1024                                                                                                                               
                                                                                                                                                       
// Function to evaluate simple arithmetic expressions                                                                                                  
double evaluate_expression(const char *expression) {                                                                                                   
    double result = 0;                                                                                                                                 
    char operator;                                                                                                                                     
    double num1, num2;                                                                                                                                 
    if (sscanf(expression, "%lf %c %lf", &num1, &operator, &num2) == 3) {                                                                              
        switch (operator) {                                                                                                                            
            case '+':                                                                                                                                  
                result = num1 + num2;                                                                                                                  
                break;                                                                                                                                 
            case '-':                                                                                                                                  
                result = num1 - num2;                                                                                                                  
                break;                                                                                                                                 
            case '*':                                                                                                                                  
                result = num1 * num2;                                                                                                                  
                break;                                                                                                                                 
            case '/':                                                                                                                                  
                if (num2 != 0) {                                                                                                                       
                    result = num1 / num2;                                                                                                              
                } else {                                                                                                                               
                    return NAN; // Return NaN for division by zero                                                                                     
                }                                                                                                                                      
                break;                                                                                                                                 
            default:                                                                                                                                   
                return NAN; // Invalid operator                                                                                                        
        }                                                                                                                                              
    } else {                                                                                                                                           
        return NAN; // Invalid format                                                                                                                  
    }                                                                                                                                                  
    return result;                                                                                                                                     
}                                                                                                                                                      
                                                                                                                                                       
int main() {                                                                                                                                           
    int server_fd, new_socket;                                                                                                                         
    struct sockaddr_in address;                                                                                                                        
    int addrlen = sizeof(address);                                                                                                                     
    char buffer[BUFFER_SIZE] = {0};                                                                                                                    
    double result;                                                                                                                                     
                                                                                                                                                       
    // Create socket file descriptor                                                                                                                   
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {                                                                                          
        perror("socket failed");                                                                                                                       
        exit(EXIT_FAILURE);                                                                                                                            
    }                                                                                                                                                  
                                                                                                                                                       
    // Define the address and port for the server                                                                                                      
    address.sin_family = AF_INET;                                                                                                                      
    address.sin_addr.s_addr = INADDR_ANY;                                                                                                              
    address.sin_port = htons(PORT);                                                                                                                    
                                                                                                                                                       
    // Bind the socket to the address and port                                                                                                         
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {                                                                           
        perror("bind failed");                                                                                                                         
        close(server_fd);                                                                                                                              
        exit(EXIT_FAILURE);                                                                                                                            
    }                                                                                                                                                  
                                                                                                                                                       
    // Listen for incoming connections                                                                                                                 
    if (listen(server_fd, 3) < 0) {                                                                                                                    
        perror("listen");                                                                                                                              
        close(server_fd);                                                                                                                              
        exit(EXIT_FAILURE);                                                                                                                            
    }                                                                                                                                                  
                                                                                                                                                       
    printf("Server is listening on port %d\n", PORT);                                                                                                  
                                                                                                                                                       
    while (1) {                                                                                                                                        
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {                                                 
            perror("accept");                                                                                                                          
            continue;                                                                                                                                  
        }                                                                                                                                              
                                                                                                                                                       
        while (1) {                                                                                                                                    
            memset(buffer, 0, BUFFER_SIZE);                                                                                                            
            int valread = read(new_socket, buffer, BUFFER_SIZE);                                                                                       
            if (valread <= 0) {                                                                                                                        
                printf("Client disconnected\n");                                                                                                       
                break;                                                                                                                                 
            }                                                                                                                                          
                                                                                                                                                       
            result = evaluate_expression(buffer);                                                                                                      
            if (isnan(result)) {                                                                                                                       
                snprintf(buffer, BUFFER_SIZE, "Error: Invalid expression");                                                                            
            } else {                                                                                                                                   
                snprintf(buffer, BUFFER_SIZE, "%lf", result);                                                                                          
            }                                                                                                                                          
                                                                                                                                                       
            send(new_socket, buffer, strlen(buffer), 0);                                                                                               
        }                                                                                                                                              
                                                                                                                                                       
        close(new_socket);                                                                                                                             
    }                                                                                                                                                  
                                                                                                                                                       
    return 0;                                                                                                                                          
} 
