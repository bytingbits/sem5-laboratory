#include <stdlib.h> 
#include <string.h>
#include <stdio.h>
void main()
{
	int op1=0; 
        int op2=0;
        int opcode=0; 
        int ck = 0; 
        char buff[100]="5+4";  
        for (int i=0; buff[i]!='\0'; i++) 
        {
        	if (buff[i]=='+')
        	{
        		opcode=1; 
        		ck=1;
        	}
        	else if (buff[i]=='-')
        	{
        		opcode=2; 
        		ck=1;
        	}
        	else if (buff[i]=='*')
        	{
        		opcode=3; ck=1;
        	}
        	else if (buff[i]=='/')
        	{
        		opcode=4; ck=1;
        	}
        	else if (ck==0)
        	{
        		op1*=10; 
        		op1 = op1 + buff[i]-48;  
        	} 
        	
        	else if(ck!=0)
        	{
        		op2*=10; 
        		op2 = op2 + buff[i]-48;
        	}
        	
        }
        int ans=0; 
        if (opcode==1)
        {
        	ans=op1+op2; 
        }
        else if(opcode==2)
        {
        	ans=op1-op2; 
        }
        else if(opcode==3)
        {
        	ans=op1*op2;
        }
        else if(opcode==4) 
        {
        	ans=op1/op2;
        }
        
        printf("%d", ans); 
        
}

