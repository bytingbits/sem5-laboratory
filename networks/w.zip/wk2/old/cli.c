#include <stdio.h>
#include <sys/socket.h>
/* Internet socket structures
* are defined in below header */
#include <netinet/in.h>
/* inet_addr is defined in
* below header */
#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
/* For read/write APIs*/
#include <unistd.h>
#define PORT 55000
/* socket file descriptor */
int socket_fd;
/* IPv4 socket structure */
struct sockaddr_in *sockaddrin = NULL;
/* Interrupt_handler so that CTRL +C can be used
* to exit the program */
void interrupt_handler (int signum) {
close(socket_fd);
free(sockaddrin);
printf("socket connection closed\n");
exit(0);
}
int main () {
char buffer[50] = {0};
char *string = "Hello from client";
/* signal handler to exit out of while 1 loop */
signal (SIGINT, interrupt_handler);
signal (SIGPIPE, interrupt_handler);
/* Part 1 – create a socket */
/* create the socket FD */
socket_fd = socket(AF_INET, SOCK_STREAM, 0);
if (socket_fd < 0) {
printf("The Socket API call failed\n");
exit(0);
}
/* Part 2 – allocate server connection details
* structure for connection */
/* allocate memory and fill the sockaddr_in structure
* so that it can be connected to the socket */
sockaddrin = (struct sockaddr_in *)malloc(sizeof(struct sockaddr_in));
if (sockaddrin == NULL) {
/* unable to allocate memory */
goto end;
}
sockaddrin->sin_family = AF_INET;
sockaddrin->sin_port = htons(PORT);
/* use loopback address (127.0.0.1)so that
* the server/client connection
* can be created on the same machine
* inet_addr API – Change the IP address from
* dotted decimal presentation form to an integer form
* suitable as an internet address */
sockaddrin->sin_addr.s_addr = inet_addr("127.0.0.1");
/* part 3 – connect to the server defined by IP address and port*/
/* connect to the server */
if (0 != connect(socket_fd, (struct sockaddr *)sockaddrin,
(socklen_t)(sizeof(struct sockaddr_in)))) {
printf("Unable to connect\n");
/* unable to connect to server */
goto end1;
}
/* Part 4 – send/receive data */
/* read and write data from/to client socket */
while (1) {
memset(buffer, 0, sizeof(buffer));
/* write data to the server */
snprintf(buffer, (strlen(string) + 1), "%s\n", string);
write(socket_fd, buffer, sizeof(buffer));
memset(buffer, 0, sizeof(buffer));
read(socket_fd, buffer, sizeof(buffer));
printf("%s\n", buffer);
}
end1:
free(sockaddrin);
end:
close(socket_fd);
}
