#include <stdlib.h> 
#include <string.h>
#include <stdio.h>
void main()
{
	int op1=0; 
        int op2=0;
        int opcode=0; 
        int ck = 0; 
        char buff[100]="513+4";  
        for (int i=0; buff[i]!='\0'; i++) 
        {
        	if (buff[i]=='+')
        	{
        		opcode=1; 
        		ck=1;
        	}
        	else if (buff[i]=='-')
        	{
        		opcode=2; 
        		ck=1;
        	}
        	else if (buff[i]=='*')
        	{
        		opcode=3; ck=1;
        	}
        	else if (buff[i]=='/')
        	{
        		opcode=4; ck=1;
        	}
        	else if (ck==0)
        	{
        		op1*=10; 
        		op1 = op1 + buff[i]-48;  
        	} 
        	
        	else if(ck!=0)
        	{
        		op2*=10; 
        		op2 = op2 + buff[i]-48;
        	}
        	
        }
        int ans=0; 
        if (opcode==1)
        {
        	ans=op1+op2; 
        }
        else if(opcode==2)
        {
        	ans=op1-op2; 
        }
        else if(opcode==3)
        {
        	ans=op1*op2;
        }
        else if(opcode==4) 
        {
        	ans=op1/op2;
        }
        int len = 0;
        int pow=1;  
        for (int a = ans; a!=0; a=a/10)
        {
        	len+=1;
        	pow*=10;  
        }
        //printf("len %d\n", len); 
        pow=pow/10;
        //printf("pow %d\n", pow);
        char ansstr[256] = {'\0'}; 
        for (int i = 0; i<len; i++)
        {
        	
        	ansstr[i]=(char) ((ans/pow)+48); 
        	//printf("%d\n", (ans/pow)+48); 
        	ans=ans%pow; 
        	pow=pow/10; 
        }
        //puts(ansstr); 
                
}

