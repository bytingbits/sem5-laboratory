import requests
data = requests.get("https://www.berkshirehathaway.com/")
print(data.status_code)
print(data.text)
print("Data header: \n", data.headers)

