//concurrent                                                                                                                                           
#include <arpa/inet.h>                                                                                                                                 
                                                                                                                                                       
#include <stdio.h>                                                                                                                                     
                                                                                                                                                       
#include <stdlib.h>                                                                                                                                    
                                                                                                                                                       
#include <string.h>                                                                                                                                    
                                                                                                                                                       
#include <sys/socket.h>                                                                                                                                
                                                                                                                                                       
#include <sys/types.h>                                                                                                                                 
                                                                                                                                                       
#include <unistd.h>                                                                                                                                    
                                                                                                                                                       
                                                                                                                                                       
                                                                                                                                                       
#define MAX 80                                                                                                                                         
                                                                                                                                                       
#define PORT 1122                                                                                                                                      
                                                                                                                                                       
#define SA struct sockaddr                                                                                                                             
                                                                                                                                                       
                                                                                                                                                       
                                                                                                                                                       
void handle_client(int connfd) {                                                                                                                       
                                                                                                                                                       
        char buff[MAX];                                                                                                                                
                                                                                                                                                       
        int n;                                                                                                                                         
                                                                                                                                                       
                                                                                                                                                       
                                                                                                                                                       
        bzero(buff, MAX);                                                                                                                              
                                                                                                                                                       
        read(connfd, buff, sizeof(buff));                                                                                                              
                                                                                                                                                       
        printf("From client: %s", buff);                                                                                                               
                                                                                                                                                       
                                                                                                                                                       
                                                                                                                                                       
        bzero(buff, MAX);                                                                                                                              
                                                                                                                                                       
        printf("To client: ");                                                                                                                         
                                                                                                                                                       
        n = 0;                                                                                                                                         
                                                                                                                                                       
        while ((buff[n++] = getchar()) != '\n')                                                                                                        
                                                                                                                                                       
                ;                                                                                                                                      
                                                                                                                                                       
        write(connfd, buff, sizeof(buff));                                                                                                             
                                                                                                                                                       
                                                                                                                                                       
                                                                                                                                                       
        close(connfd);                                                                                                                                 
                                                                                                                                                       
}                                                                                                                                                      
                                                                                                                                                       
                                                                                                                                                       
                                                                                                                                                       
int main() {                                                                                                                                           
                                                                                                                                                       
        int sockfd, connfd, len;                                                                                                                       
                                                                                                                                                       
        struct sockaddr_in servaddr, cli;                                                                                                              
                                                                                                                                                       
        pid_t childpid;                                                                                                                                
                                                                                                                                                       
                                                                                                                                                       
                                                                                                                                                       
        sockfd = socket(AF_INET, SOCK_STREAM, 0);                                                                                                      
                                                                                                                                                       
        if (sockfd == -1) {                                                                                                                            
                                                                                                                                                       
                perror("Socket creation failed");                                                                                                      
                                                                                                                                                       
                exit(0);                                                                                                                               
                                                                                                                                                       
        } else                                                                                                                                         
                                                                                                                                                       
                printf("Socket successfully created\n");                                                                                               
                                                                                                                                                       
        bzero(&servaddr, sizeof(servaddr));                                                                                                            
                                                                                                                                                       
                                                                                                                                                       
                                                                                                                                                       
        servaddr.sin_family = AF_INET;                                                                                                                 
                                                                                                                                                       
        servaddr.sin_addr.s_addr = htonl(INADDR_ANY);                                                                                                  
                                                                                                                                                       
        servaddr.sin_port = htons(PORT);                                                                                                               
                                                                                                                                                       
                                                                                                                                                       
                                                                                                                                                       
        if (bind(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) {                                                                                     
                                                                                                                                                       
                perror("Socket bind failed");                                                                                                          
                                                                                                                                                       
                exit(0);                                                                                                                               
                                                                                                                                                       
        } else                                                                                                                                         
                                                                                                                                                       
                printf("Socket successfully binded\n");                                                                                                
                                                                                                                                                       
                                                                                                                                                       
                                                                                                                                                       
        if (listen(sockfd, 5) != 0) {                                                                                                                  
                                                                                                                                                       
                perror("Listen failed");                                                                                                               
                                                                                                                                                       
                exit(0);                                                                                                                               
                                                                                                                                                       
        } else                                                                                                                                         
                                                                                                                                                       
                printf("Server listening\n");                                                                                                          
                                                                                                                                                       
        len = sizeof(cli);                                                                                                                             
                                                                                                                                                       
                                                                                                                                                       
                                                                                                                                                       
        while (1) {                                                                                                                                    
                                                                                                                                                       
                connfd = accept(sockfd, (SA*)&cli, &len);                                                                                              
                                                                                                                                                       
                if (connfd < 0) {                                                                                                                      
                                                                                                                                                       
                        perror("Server accept failed");                                                                                                
                                                                                                                                                       
                        exit(0);                                                                                                                       
                                                                                                                                                       
                } else                                                                                                                                 
                                                                                                                                                       
                        printf("Server accepted client\n");                                                                                            
                                                                                                                                                       
                                                                                                                                                       
                                                                                                                                                       
                if ((childpid = fork()) == 0) {                                                                                                        
                                                                                                                                                       
                        close(sockfd);                                                                                                                 
                                                                                                                                                       
                        handle_client(connfd);                                                                                                         
                                                                                                                                                       
                        exit(0);                                                                                                                       
                                                                                                                                                       
                } else if (childpid < 0) {                                                                                                             
                                                                                                                                                       
                        perror("Fork failed");                                                                                                         
                                                                                                                                                       
                        exit(0);                                                                                                                       
                                                                                                                                                       
                }                                                                                                                                      
                                                                                                                                                       
                close(connfd);                                                                                                                         
                                                                                                                                                       
        }                                                                                                                                              
                                                                                                                                                       
                                                                                                                                                       
                                                                                                                                                       
        close(sockfd);                                                                                                                                 
                                                                                                                                                       
        return 0;                                                                                                                                      
                                                                                                                                                       
}              
