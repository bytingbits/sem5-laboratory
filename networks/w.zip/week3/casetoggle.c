#include <stdio.h>
#include <string.h>

int main()
{
	char buff[100]; 
	gets(buff); 
	for (int i=0; i<strlen(buff); i++)
	{
		if (buff[i]>='a' && buff[i]<='z')
		{
			buff[i]=buff[i]-32; 
		}
		else if (buff[i]>='A' && buff[i]<='Z')
		{
			buff[i]=buff[i]+32; 
		}
	
	}
	puts(buff); 
}
