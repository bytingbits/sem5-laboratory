#include <stdio.h> 
#include <string.h>

void main()
{
	int s1[100]={'o'}; 
	for (int i=0;i<100;i++)
	printf("%d", s1[i]); 
} 
