#include <stdio.h> 
#include <string.h>

char mains[100] = "heilo";
char build[100];  
void subStr(int i, int ptr, int incl, char* mains)
{
	if (i==strlen(mains))
	{
		puts(build); 
		for (int i=0; i<strlen(build); i++) 
			build[i]='\0';
		
	}
	else
	{
	puts(build); 
	if (incl == 1) 
		build[ptr]=mains[i]; 
	//puts(build); 
	//subStr(i+1, ptr+1, 0);
		//subStr(i+1, ptr, 0, mains);
	subStr(i+1, ptr+1, 1, mains);
	//subStr(i+1, ptr, 1);
	//puts(build);
	}
}
 
void main() 
{
/**for (int i=0; i<strlen(build); i++) 
	build[i]='\0';*/ 
int i = 0; 
int ptr = 0; 
subStr(0,0,1, mains); 
for(int i=0; i<strlen(mains); i++)
{
	//mains=&(mains[i]); 
	subStr(0, 0, 1, &mains[i]);  
	printf("%d", strlen(&mains[i]));  
}	 
}
	
